﻿#Script que limpa o corpus taggeado#

#Motivo - O treetagger deixou o corpus cheio de lixos, não sei o que acontece.


#Objetivo:  Abrir um .txt no formato:

        ## Palavra \t Categoria Morfossintática \t Lemma

# E excluir algumas categorias que não são importantes, no caso

# QUOTE - não sei por que teve tanta.
# B - unidades de medida abreviadas.
# BLANK - não sei o que aconteceu, mas foi um erro com quote
# VIRG - vírgula foi classificada no tagger?
# X - não foram classificadas
# SENT - pontuação
# CARD - número

#Então gravar um txt no mesmo formato.

#definindo uma função auxiliar para eliminar strings com numeros
def hasnum(string):
    for item in string:
        if item in '1234567890':
            return True
        else:
            return False


import codecs

arquivo = codecs.open('Corpus_Total_Taggeado.txt','r','utf8')
origem = arquivo.read().split('\n')
with codecs.open('Corpus_Total_limpo.txt','w','utf8') as destino:
    for linha in origem:
        
        listinha = linha.split(u'\t')
        if listinha[0] in [u'QUOTE', u'-', u"'",u'’',u'‘', u'"', u'%',u'--', u'“', u'”', u'—'] or len(listinha) < 3 or hasnum(listinha[0])==True :
            pass
        elif listinha[1] in [u'QUOTE',u'B',u'BLANK',u'VIRG',u'X',u'SENT',u'CARD']:
            pass
        
        else:
            destino.write(unicode(linha))

arquivo.close()

