import codecs

from ftfy import fix_text

with codecs.open('Palavras_ProjetoSP_TAGGEADAS.txt','rU','utf8',errors='replace') as x:
    arquivo = (x.read())




with codecs.open('Palavras_ProjetoSP_Final.txt','w','utf8') as y:
    for linha in arquivo:
        y.write(fix_text(linha))
        
    

