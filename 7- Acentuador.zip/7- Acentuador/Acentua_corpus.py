## -*- coding: utf-8 -*-
from __future__ import unicode_literals
import codecs
execfile('acentuador.py')

arquivo = codecs.open('Corpus_Tag_Freq_Trans.txt','r','utf8')

corpus_tag_freq = arquivo.read().split(u'\n')
corpus_total = []
for item in corpus_tag_freq:
    corpus_total.append(item.split('\t'))
for item in corpus_total:
    item.pop(-1)

#Formato do corpus agora é:
    #[palavra,categoria,lema,transcrição,freq_total,freq_oral,freq_escrita]
arquivo.close()


#Com esse loop eu vou ter o corpus do seguinte formato:
    #[palavra,categoria,lema,transcrição, acentuada, estrutura silábica, cat_acentual, freq_total,freq_oral,freq_escrita]

for item in corpus_total:
    try:
        item = acentuador(item)
    except:
        while len(item) < 10:
            item.insert(4,'erro')
        

with codecs.open('Corpus_Tag_Freq_Trans_Ac.txt','w','utf8') as destino:
    for item in corpus_total:
        uni = u''
        for elemento in item:
            uni +=  elemento + ' \t '
        destino.write(uni+'\n')
    
