# -*- coding: cp1252 -*-
##Silabificador para Portugues Brasileiro##
## 18-09-2012 ##

from __future__ import unicode_literals
###########################################################
#                                                         #
# Define a função **silabas**,                            #
# que toma como input uma string                          #
# (transcrição fonética com os sons definidos abaixo)     #
# e retorna uma outra string, silabificada.               #
#                                                         #
# Exemplo:                                                #
# silabas('partw') = 'par-tw'                             #
#                                                         #
###########################################################



import string
#from listacompleta import *

##################################
##### Classificação dos sons #####
##################################

oclusivas = ['p','b','t','d','k','q','g','c']
fricativas = ['f','v','s','z','S','j','h','x'] # S = ch de chato; j de jato ou gelo; h = erre de rato
africadas = ['T','D'] # T de tia; D de dia
liquidas = ['l','L','r'] #L = lh de calha; l de cala; r de caro (mas nao de rato)
nasais = ['m','n','N'] # n de cano; N = nh de canhoto
semivogais = ['J','W'] # J = i de pai (mas nao de país); W = u de pau (mas não de baú)
#vogais = ['@','a','e','3','i','y','o','0','u','w']
            # @(arroba): a final de casa, 3(três): e de ela, y: e final de forte, 0(zero): o de otima, w: o final de parto
##### VER CODIFICAÇÃO
vogais = ['a','e','i','y','o','u']
vogais_nasais = ['A','E','I','O','U'] # vogais nasais do portugues

especiais = ['r','s','z','n'] # ver REPARO mais abaixo



################################
##### Escala de Sonoridade #####
################################

def sonoridade(fone):
    if fone in oclusivas or fone in africadas:
        return 0
    elif fone in fricativas:
        return 1
    elif fone in nasais:
        return 2
    elif fone in liquidas or fone == 'L':
        return 3
    elif fone in semivogais:
        return 4
    elif fone in vogais or fone in vogais_nasais:
        return 5
    else:
        return 'erro'


#########################
##### Silabificador #####
#########################
    
def silabas(palavra): # o input é uma string (transcrição fonética) com os sons definidos acima
                      # o output é uma string silabificada (o separador é o hifen '-')
    
    res = []   # para guardar os resultados parciais da silabificação

    index = 0  # para percorrer o input da esquerda para a direita

    while index < len(palavra):

        #inicio de palavra (nunca se coloca o separador de silaba antes do primeiro fone)
        if index == 0: 
            res = res + [palavra[index]]
            
        #hiatos (duas vogais adjacentes sempre estão em silabas separadas)
        elif sonoridade(palavra[index]) == sonoridade(palavra[index-1]) == 5: 
            res = res + ['-'] + [palavra[index]]
            
        #diante do último fone (nunca se coloca o separador de silaba entre o penultimo e o ultimo fone,
        #a não ser que seja o meio de um hiato (caso anterior)
        elif index == len(palavra) - 1: 
            res = res + [palavra[index]]
            
        #vale(pico negativo) de sonoridade - _ - ou _ _ -
        #(insere o separador de silaba antes do pico negativo)
        elif sonoridade(palavra[index]) <= sonoridade(palavra[index-1]) and \
             sonoridade(palavra[index]) < sonoridade(palavra[index+1]):
            res = res + ['-'] + [palavra[index]]
            
        #demais casos (ditongos, por exemplo, não devem ser separados)
        else: 
            res = res + [palavra[index]]

        index = index + 1

############################# REPARO #########################################       
#                                                                            #
#   'h'(fricativa velar) seguido de liquida ou nasal nao forma bons onsets e #
#   precisa ser incorporado na coda anterior. Por exemplo:                   #  
#   o-xla --> ox-la; o-xna --> ox-na                                         #
#   O mesmo vale para os demais simbolos classificados como especiais acima. #
#                                                                            #
##############################################################################
        
    index = 0
    while index < len(res) - 2:
        if (res[index] == '-' and res[index+1] in especiais and (res[index+2] in nasais or res[index+2] in liquidas)):
            res[index] = res[index+1]
            res[index+1] = '-'
        else:
            res[index] = res[index]
        index = index + 1
        
    return string.join(res,'')


### FIM ###







            
