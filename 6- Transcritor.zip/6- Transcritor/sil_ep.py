# -*- coding: utf-8 -*-
#PARTE-2
#EPENTESE + SILABIFICAÇÃO
from __future__ import unicode_literals
execfile('epentese.py')
execfile('silabificador.py')

def sil_ep(palavra):
	#recebe uma palavra ortográfica, faz epêntese,
        #silabifica e adiciona os símbolos de início e final de palavra
	palavra2 = epentese(palavra)
	palavra2 = silabas(palavra2)
	palavra2 = '&' + palavra2  + '*'
	return palavra2

