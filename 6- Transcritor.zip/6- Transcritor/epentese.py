# -*- coding: utf-8 -*-
#PARTE 1
from __future__ import unicode_literals
vogais = 'aeiouÃ£Ãµ'

def elimina_2C (palavra):
    #Esse programa recebe uma palavra ortográfica sem tratamento e elimina dígrafos
    i = 0
    copia = []
    for letra in palavra:
        copia += letra
    while i < len(copia)-2:
        letra = copia[i]
        if letra == 'r' and copia[i+1] == 'r':#carro -> caho
            del copia [i+1]
            copia[i] = 'h'
        elif letra == 'l' and copia[i+1] == 'l':#gabriella -> gabriela
            del copia [i+1]
            copia[i] = 'l'
        elif letra == 'n' and copia[i+1] == 'n':#giovanne -> giovane
            del copia [i+1]
            copia[i] = 'n'
        elif letra == 't' and copia[i+1] == 't':#anitta -> anita
            del copia [i+1]
            copia[i] = 't'
        elif letra == 'f' and copia[i+1] == 'f': #jefferson -> jeferson
            del copia [i+1]
            copia[i] = 'f'
        elif letra == 'n' and copia[i+1] == 'h': # unha -> uNa
            del copia[i+1]
            copia[i] = 'N'
        elif letra == 'l' and copia[i+1] == 'h':# coelho -> coeLo
            del copia[i+1]
            copia[i] = 'L'
        elif letra == 'c' and copia[i+1] == 'h':# chácara -> Sácara
            del copia[i+1]
            copia[i] = 'S'
        elif letra == 's' and copia[i+1] == 'h':# sheila -> Seila
            del copia[i+1]
            copia[i] = 'S'
        elif letra in 'q' and (copia[i+1] == 'u' and copia[i+2] in vogais):#Quadro -> qadro
        	del copia[i+1]
        	copia[i] = letra
        elif letra in 'q' and (copia[i+1] == 'u' and copia[i+2] in vogais): #Cinquenta -> cinqenta -> Transcrição de palavras que tinham trema são um problema.
        	del copia[i+1]
        	copia[i] = letra
        elif letra == 'h':#hora -> ora
            del copia[i]
        i = i+1
    string = ''
    for item in copia: #formatando o output
        string += item
    
    return string


def epentese (palavra):
    # RECEBE A PALAVRA SEM DÍGRAFOS E RETORNA EM CONTEXTO DE EPÊNTESE UMA SEMI-TRANSCRIÇÃO CONTENDO A VOGAL EPENTÉTICA
    palavra = elimina_2C(palavra) 
    copia = []
    for letra in palavra:
        copia += letra
    copia += '*'
    consoantes1 = 'bcdfghjkpqtv'
    consoantes2 = 'bcdfghjkmnpqtvxsz*'
    
    if (copia[1]in consoantes1 and copia[0] in consoantes2) :#Para casos de epêntese no início de palavra como skate.
        copia.insert(0,'y')
    i = 0
    while i < len(copia) - 1: #Para os demais casos de epêntese, como internet e advogado
        if copia[i] in consoantes1 and (copia[i+1] in consoantes2):
            copia[i] += 'y'
        i += 1
    string = ''
    for item in copia:#formatando o output
        if item == '*':
            pass
        else:
            string += item
    return string




            
    
